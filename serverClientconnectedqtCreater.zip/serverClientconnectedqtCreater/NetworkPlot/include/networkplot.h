#ifndef NETWORKPLOT_H
#define NETWORKPLOT_H

#include <QMainWindow>
#include<QVector>
#include<QPen>
#include<QTimer>
#include"serverthread.h"
#include"qcustomplot.h"
#include<QDebug>

QT_BEGIN_NAMESPACE
namespace Ui { class NetworkPlot; }
QT_END_NAMESPACE

class NetworkPlot : public QMainWindow
{
    Q_OBJECT

public:
    NetworkPlot(QWidget *parent = nullptr);
    ~NetworkPlot();

        QPen Pen,Pen1;
        QTimer *timer;

        public slots:
           void parseData(QByteArray);
           void myfunction();

private:
    Ui::NetworkPlot *ui;


};
#endif // NETWORKPLOT_H
