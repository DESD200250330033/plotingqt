#include "../include/mythread.h"


MyThread::MyThread(qintptr ID, QObject *parent)
{
    this->socketDescriptor = ID;
}

void MyThread::run()
{
    qDebug()<<"Thread Starting";
    socket = new QTcpSocket();
    if(!socket->setSocketDescriptor(this->socketDescriptor)){
        emit error(socket->error());
        return;
    }
    connect(socket,SIGNAL(readyRead()),this,SLOT(readyRead()),Qt::DirectConnection);
    connect(socket,SIGNAL(disconnected()),this,SLOT(disconnected()));
    qDebug()<<socketDescriptor<<"Client Connected";

    exec();
}

void MyThread::readyRead()
{
QByteArray Data = socket->readAll();

//qDebug()<<socketDescriptor<<"Data in:"<<Data;

//addding to data plot using clinet runing

emit newDataRecieved(Data);

//qDebug()<<"newDataRecieved calling";
}

void MyThread::disconnected()
{
    qDebug()<<socketDescriptor<<"Disconnected";

    socket->deleteLater();
    exit(0);
}
