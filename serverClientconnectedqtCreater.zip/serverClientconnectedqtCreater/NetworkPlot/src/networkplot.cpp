#include "networkplot.h"
#include "ui_networkplot.h"
#include<QPen>
#include<QTimer>
#include<QDebug>
#include"serverthread.h"


NetworkPlot::NetworkPlot(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::NetworkPlot)
{
    ui->setupUi(this);



/*
timer = new QTimer(this);
connect(time,SIGNAL(timeout(),SLOT(myfunction())));
timer(1000);*/

/*
 QTimer *timer = new QTimer(this);
     connect(timer, SIGNAL(timeout()), this, SLOT(myfunction()));
     timer->start(1000);

    Pen.width();
    Pen.setColor(Qt::red);

*/
    ui->customplot->addGraph();

   ui->customplot->graph(0)->setScatterStyle(QCPScatterStyle::ssCircle);
    ui->customplot->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->customplot->xAxis->setLabel("X_RANGE");
     ui->customplot->yAxis->setLabel("Y_RANGE");
     ui->customplot->xAxis->setRange(-50,50);
     ui->customplot->yAxis->setRange(-50,50);
     ui->customplot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom |QCP::iSelectPlottables);
//for()
    /*QVector<double>x={1,2,3,4,5},y={4,6,8,2,5};
     //ui->customplot->graph(0)->setPen(Pen);
     ui->customplot->graph(0)->setData(x,y);
     ui->customplot->rescaleAxes();
     ui->customplot->replot();
     ui->customplot->update();*/


     ServerThread *thread =new ServerThread(this);
     connect(thread,SIGNAL(newDataRecieved(QByteArray)),this,SLOT(parseData(QByteArray)));
     thread->start();


}

NetworkPlot::~NetworkPlot()
{
    delete ui;
}

void NetworkPlot::parseData(QByteArray Data)
{
 qDebug()<<"Go data:"<<Data;
 //qDebug()<<"Parse function printing";

 QJsonParseError parseError;
 QJsonDocument jsonResponse = QJsonDocument::fromJson(Data,&parseError);

 if(parseError.error != QJsonParseError::NoError)
 {
  qDebug()<<"parse Error"<<parseError.errorString();
  return;
 }
 QJsonArray jsonArray = jsonResponse.array();

 if(!jsonArray.isEmpty())
 {
     QJsonObject jsonObject = jsonArray.first().toObject();

     QVector<double>x,y;

     for(int i=0;i<jsonObject.value("X").toArray().size();i++)
     {
      x.push_back(jsonObject.value("X").toArray()[i].toDouble());
      y.push_back(jsonObject.value("Y").toArray()[i].toDouble());
     }


     ui->customplot->graph(0)->setData(x,y);
     ui->customplot->rescaleAxes();
     ui->customplot->replot();
     ui->customplot->update();

 }
}


void NetworkPlot::myfunction()
{
    static double ii,jj;

    Pen1.width();
    Pen1.setColor(Qt::red);

    ii=ii+1.2;
    jj= jj+5;



    QVector<double>x={ii},y={jj};


    ui->customplot->graph(0)->setData(x,y);
    ui->customplot->graph(0)->setPen(Pen1);
    ui->customplot->rescaleAxes();
    ui->customplot->replot();
    ui->customplot->update();

//qdebug()<<"Hello word\n";

qDebug("Hello word");


}



